/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.taxcalculatorgui;

/**
 *
 * @author Cole.Hanekom
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TaxCalculatorGUI extends JFrame implements ActionListener {
    private JTextField incomeTextField;
    private JTextField resultTextField;
    private JTextField netSalaryTextField;

    public TaxCalculatorGUI() {
        setTitle("Tax Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(480, 400); // Increased size of the GUI
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Create a JPanel with a background image
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Load the background image
                Image backgroundImage = new ImageIcon("C:\\Users\\Cole.Hanekom\\Documents\\NetBeansProjects\\TaxCalculatorGUI\\d4.jpg").getImage();
                // Draw the image on the panel, scaling it to fit the panel's size
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        };
        
        JLabel headingLabel = new JLabel("Tax Calculator");
        headingLabel.setFont(new Font("Arial", Font.BOLD, 65));
        headingLabel.setForeground(Color.white);
        headingLabel.setHorizontalAlignment(SwingConstants.CENTER);


        JPanel inputPanel = new JPanel();
        inputPanel.setOpaque(false); // Make the input panel transparent
        inputPanel.setLayout(new GridBagLayout()); // Use GridBagLayout for inputPanel

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10, 10, 10, 10); // Add some padding

        JLabel incomeLabel = new JLabel("Annual Income:");
        incomeTextField = new JTextField(10);
       incomeLabel.setForeground(Color.white);
        incomeLabel.setFont(new Font("Arial", Font.BOLD, 30));


        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(incomeLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL; // Set fill property to HORIZONTAL
        inputPanel.add(incomeTextField, gbc);

        JButton calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(this);
        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(this);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2; // Span two columns
        gbc.fill = GridBagConstraints.NONE; // Reset fill property
        inputPanel.add(calculateButton, gbc);

        gbc.gridy = 3;
        inputPanel.add(clearButton, gbc);

        JPanel resultPanel = new JPanel();
        resultPanel.setOpaque(false); // Make the result panel transparent
        resultPanel.setLayout(new GridBagLayout()); // Use GridBagLayout for resultPanel

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;

        JLabel resultLabel = new JLabel("Tax Obligation:");
        resultTextField = new JTextField(10);
        resultTextField.setEditable(false);
        resultTextField.setBorder(null);
        resultLabel.setForeground(Color.white);
        resultLabel.setFont(new Font("Arial", Font.BOLD, 30));
        resultTextField.setFont(new Font("Arial", Font.BOLD, 15));

        JLabel netSalaryLabel = new JLabel("Net Salary:");
        netSalaryTextField = new JTextField(10);
        netSalaryTextField.setEditable(false);
        netSalaryTextField.setBorder(null);
        netSalaryLabel.setForeground(Color.white);
        netSalaryLabel.setFont(new Font("Arial", Font.BOLD, 30));
        netSalaryTextField.setFont(new Font("Arial", Font.BOLD, 15));

        resultPanel.add(resultLabel, gbc);

        gbc.gridx = 1;
        resultPanel.add(resultTextField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        resultPanel.add(netSalaryLabel, gbc);

        gbc.gridx = 1;
        resultPanel.add(netSalaryTextField, gbc);

        // Add components to the background panel
        backgroundPanel.add(headingLabel, BorderLayout.NORTH);
        backgroundPanel.add(inputPanel, BorderLayout.CENTER);
        backgroundPanel.add(resultPanel, BorderLayout.SOUTH);

        // Set the background panel as the content pane
        setContentPane(backgroundPanel);
    }

 

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Calculate")) {
            String incomeText = incomeTextField.getText();

 

            try {
                double annualIncome = Double.parseDouble(incomeText);
                double taxObligation = calculateTaxObligation(annualIncome);
                resultTextField.setText(String.format("R%.2f", taxObligation));

 

                double netSalary = annualIncome - taxObligation;
                netSalaryTextField.setText(String.format("R%.2f", netSalary));
            } catch (NumberFormatException ex) {
                resultTextField.setText("Enter a valid number.");
                netSalaryTextField.setText("");
            }
        } else if (e.getActionCommand().equals("Clear")) {
            incomeTextField.setText("");
            resultTextField.setText("");
            netSalaryTextField.setText("");
        }
    }

 

    public double calculateTaxObligation(double annualIncome) {
        double taxObligation = 0;

 

        // Apply tax calculation rules based on the income brackets
        if (annualIncome <= 237100) {
            taxObligation = annualIncome * 0.18; //18% of taxable income
        } else if (annualIncome <= 370500) {
            taxObligation = (237100 * 0.18) + ((annualIncome - 237100) * 0.26);
        } else if (annualIncome <= 512800) {
            taxObligation = (237100 * 0.18) + (115700 * 0.26) + ((annualIncome - 370500) * 0.31);
        } else if (annualIncome <= 673000) {
            taxObligation = (237100 * 0.18) + (115700 * 0.26) + (123500 * 0.31) + ((annualIncome - 512800) * 0.36);
        } else if (annualIncome <= 857900) {
            taxObligation = (237100 * 0.18) + (115700 * 0.26) + (123500 * 0.31) + (139100 * 0.36) + ((annualIncome - 673000) * 0.39);
        } else if (annualIncome <=  1817000) {
            taxObligation = (237100 * 0.18) + (115700 * 0.26) + (123500 * 0.31) + (139100 * 0.36) + (160600 * 0.39) + ((annualIncome - 857900) * 0.41);
        } else {
            taxObligation = (237100 * 0.18) + (115700 * 0.26) + (123500 * 0.31) + (139100 * 0.36) + (160600 * 0.39) + (828500 * 0.41) + ((annualIncome - 1817000) * 0.45);
        }

 

        return taxObligation;
    }

 

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                TaxCalculatorGUI taxCalculatorGUI = new TaxCalculatorGUI();
                taxCalculatorGUI.setVisible(true);
            }
        });
    }
}
